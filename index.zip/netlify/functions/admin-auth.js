const crypto = require('crypto');

const SESSION_COOKIE = 'ws_admin_session';
const SESSION_TTL_SECONDS = 8 * 60 * 60;
const LOGIN_WINDOW_MS = 10 * 60 * 1000;
const LOGIN_MAX_ATTEMPTS = 10;
const LOCK_AFTER_FAILURES = 5;
const LOCK_MS = 15 * 60 * 1000;

const DEFAULT_ADMIN_USER = 'admin';
const DEFAULT_ADMIN_PASSWORD_HASH =
  'b106e93677d847f4b8c4df7c4355ef5a12a414ebf102763481cac3f2f4f2d524';
const FALLBACK_SECRET_SEED = 'wahat-admin-session-fallback-v1';

const loginBuckets = new Map();

function sha256(text) {
  return crypto.createHash('sha256').update(text).digest('hex');
}

function base64UrlEncode(input) {
  return Buffer.from(input)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

function base64UrlDecode(input) {
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);
  return Buffer.from(padded, 'base64').toString('utf8');
}

function base64UrlToBuffer(input) {
  const normalized = String(input).replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);
  return Buffer.from(padded, 'base64');
}

function signPayload(payloadString, secret) {
  return crypto
    .createHmac('sha256', secret)
    .update(payloadString)
    .digest('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

function parseCookies(event) {
  const raw = event.headers?.cookie || event.headers?.Cookie || '';
  if (!raw) return {};
  return raw.split(';').reduce((acc, pair) => {
    const idx = pair.indexOf('=');
    if (idx <= 0) return acc;
    const key = pair.slice(0, idx).trim();
    const value = pair.slice(idx + 1).trim();
    acc[key] = value;
    return acc;
  }, {});
}

function getClientIp(event) {
  const forwarded = event.headers?.['x-forwarded-for'] || event.headers?.['X-Forwarded-For'];
  if (forwarded) {
    return String(forwarded).split(',')[0].trim();
  }
  return event.headers?.['client-ip'] || event.headers?.['Client-Ip'] || 'unknown';
}

function isAllowedOrigin(origin) {
  if (!origin) return true;
  try {
    const parsed = new URL(origin);
    const { hostname, protocol } = parsed;
    if (!/^https?:$/.test(protocol)) return false;
    if (hostname === 'localhost' || hostname === '127.0.0.1') return true;
    if (origin === 'https://wahat-sudr.netlify.app') return true;
    if (/^[a-z0-9-]+--wahat-sudr\.netlify\.app$/i.test(hostname)) return true;

    const known = [process.env.URL, process.env.DEPLOY_PRIME_URL]
      .filter(Boolean)
      .map((u) => {
        try {
          return new URL(u).hostname;
        } catch {
          return null;
        }
      })
      .filter(Boolean);

    return known.includes(hostname);
  } catch {
    return false;
  }
}

function buildHeaders(origin) {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    Vary: 'Origin'
  };

  if (origin && isAllowedOrigin(origin)) {
    headers['Access-Control-Allow-Origin'] = origin;
    headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS';
    headers['Access-Control-Allow-Headers'] = 'Content-Type';
    headers['Access-Control-Allow-Credentials'] = 'true';
  }

  return headers;
}

function cookieAttributes(event) {
  const proto =
    event.headers?.['x-forwarded-proto'] ||
    event.headers?.['X-Forwarded-Proto'] ||
    '';
  const isHttps = String(proto).toLowerCase().includes('https');
  return {
    sameSite: 'SameSite=Strict',
    secure: isHttps ? 'Secure' : null
  };
}

function setCookieHeader(token, event) {
  const attrs = cookieAttributes(event);
  const parts = [
    `${SESSION_COOKIE}=${token}`,
    'Path=/',
    `Max-Age=${SESSION_TTL_SECONDS}`,
    'HttpOnly',
    attrs.sameSite
  ];
  if (attrs.secure) parts.push(attrs.secure);
  return parts.join('; ');
}

function clearCookieHeader(event) {
  const attrs = cookieAttributes(event);
  const parts = [`${SESSION_COOKIE}=`, 'Path=/', 'Max-Age=0', 'HttpOnly', attrs.sameSite];
  if (attrs.secure) parts.push(attrs.secure);
  return parts.join('; ');
}

function buildSessionToken(user, secret) {
  const now = Math.floor(Date.now() / 1000);
  const payload = {
    sub: user,
    iat: now,
    exp: now + SESSION_TTL_SECONDS,
    n: crypto.randomBytes(8).toString('hex')
  };

  const payloadString = JSON.stringify(payload);
  const encodedPayload = base64UrlEncode(payloadString);
  const signature = signPayload(payloadString, secret);
  return `${encodedPayload}.${signature}`;
}

function verifySessionToken(token, secret) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encodedPayload, signature] = parts;
  if (!encodedPayload || !signature) return null;

  let payloadString;
  try {
    payloadString = base64UrlDecode(encodedPayload);
  } catch {
    return null;
  }

  const expected = signPayload(payloadString, secret);
  const sigBuf = base64UrlToBuffer(signature);
  const expBuf = base64UrlToBuffer(expected);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }

  try {
    const payload = JSON.parse(payloadString);
    const now = Math.floor(Date.now() / 1000);
    if (!payload.exp || payload.exp < now) return null;
    if (!payload.sub || typeof payload.sub !== 'string') return null;
    return payload;
  } catch {
    return null;
  }
}

function trackLoginAttempt(ip, success) {
  const now = Date.now();
  const bucket = loginBuckets.get(ip) || { attempts: [], failures: 0, lockedUntil: 0 };

  bucket.attempts = bucket.attempts.filter((ts) => now - ts < LOGIN_WINDOW_MS);
  bucket.attempts.push(now);

  if (success) {
    bucket.failures = 0;
    bucket.lockedUntil = 0;
  } else {
    bucket.failures += 1;
    if (bucket.failures >= LOCK_AFTER_FAILURES) {
      bucket.lockedUntil = now + LOCK_MS;
    }
  }

  loginBuckets.set(ip, bucket);
}

function canAttemptLogin(ip) {
  const now = Date.now();
  const bucket = loginBuckets.get(ip);
  if (!bucket) return { allowed: true };

  if (bucket.lockedUntil && bucket.lockedUntil > now) {
    return { allowed: false, reason: 'locked', retryAt: bucket.lockedUntil };
  }

  const attempts = bucket.attempts.filter((ts) => now - ts < LOGIN_WINDOW_MS);
  bucket.attempts = attempts;
  loginBuckets.set(ip, bucket);

  if (attempts.length >= LOGIN_MAX_ATTEMPTS) {
    return { allowed: false, reason: 'rate_limited', retryAt: attempts[0] + LOGIN_WINDOW_MS };
  }

  return { allowed: true };
}

function getConfiguredPasswordHash() {
  if (process.env.ADMIN_PASSWORD_HASH) {
    return String(process.env.ADMIN_PASSWORD_HASH).trim().toLowerCase();
  }
  if (process.env.ADMIN_PASSWORD) {
    return sha256(String(process.env.ADMIN_PASSWORD));
  }
  return DEFAULT_ADMIN_PASSWORD_HASH;
}

function getSessionSecret() {
  const configured = String(process.env.ADMIN_SESSION_SECRET || '').trim();
  if (configured.length >= 24) return configured;

  const seed = [
    process.env.SITE_ID || '',
    process.env.URL || '',
    process.env.ADMIN_USER || DEFAULT_ADMIN_USER,
    getConfiguredPasswordHash(),
    FALLBACK_SECRET_SEED
  ].join('|');

  // Stable fallback to keep auth endpoint operational when env secret is missing.
  return sha256(seed);
}

function unauthorized(headers) {
  return {
    statusCode: 401,
    headers,
    body: JSON.stringify({ error: 'Unauthorized' })
  };
}

exports.handler = async (event) => {
  const origin = event.headers?.origin || event.headers?.Origin || '';
  const headers = buildHeaders(origin);

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  if (origin && !isAllowedOrigin(origin)) {
    return { statusCode: 403, headers, body: JSON.stringify({ error: 'Origin not allowed' }) };
  }

  const sessionSecret = getSessionSecret();

  const cookies = parseCookies(event);
  const currentSession = verifySessionToken(cookies[SESSION_COOKIE], sessionSecret);

  if (event.httpMethod === 'GET') {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ authenticated: Boolean(currentSession), user: currentSession?.sub || null })
    };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  if (!event.body || event.body.length > 5000) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid request body' }) };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const action = body?.action;
  if (action === 'status') {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ authenticated: Boolean(currentSession), user: currentSession?.sub || null })
    };
  }

  if (action === 'logout') {
    return {
      statusCode: 200,
      headers: {
        ...headers,
        'Set-Cookie': clearCookieHeader(event)
      },
      body: JSON.stringify({ ok: true })
    };
  }

  if (action !== 'login') {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid action' }) };
  }

  const ip = getClientIp(event);
  const attempt = canAttemptLogin(ip);
  if (!attempt.allowed) {
    const retryAfter = Math.max(1, Math.ceil((attempt.retryAt - Date.now()) / 1000));
    return {
      statusCode: 429,
      headers: {
        ...headers,
        'Retry-After': String(retryAfter)
      },
      body: JSON.stringify({ error: 'Too many login attempts', retry_after: retryAfter })
    };
  }

  const username = String(body.username || '').trim();
  const password = String(body.password || '');

  if (!username || !password || password.length > 512) {
    trackLoginAttempt(ip, false);
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid credentials format' }) };
  }

  const adminUser = process.env.ADMIN_USER || DEFAULT_ADMIN_USER;
  const adminHash = getConfiguredPasswordHash();
  const incomingHash = sha256(password);

  const validUser = username === adminUser;
  const validPassword =
    incomingHash.length === adminHash.length &&
    crypto.timingSafeEqual(Buffer.from(incomingHash), Buffer.from(adminHash));

  if (!validUser || !validPassword) {
    trackLoginAttempt(ip, false);
    return unauthorized(headers);
  }

  trackLoginAttempt(ip, true);

  const token = buildSessionToken(adminUser, sessionSecret);
  return {
    statusCode: 200,
    headers: {
      ...headers,
      'Set-Cookie': setCookieHeader(token, event)
    },
    body: JSON.stringify({ ok: true, user: adminUser })
  };
};
