const crypto = require('crypto');
const { connectLambda, getStore } = require('@netlify/blobs');

const STORE_NAME = 'wahat-site-data';
const STORE_KEY = 'announcement';
const SESSION_COOKIE = 'ws_admin_session';
const DEFAULT_ADMIN_USER = 'admin';
const DEFAULT_ADMIN_PASSWORD_HASH =
  'b106e93677d847f4b8c4df7c4355ef5a12a414ebf102763481cac3f2f4f2d524';
const FALLBACK_SECRET_SEED = 'wahat-admin-session-fallback-v1';

function base64UrlDecode(input) {
  const normalized = String(input).replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);
  return Buffer.from(padded, 'base64').toString('utf8');
}

function base64UrlToBuffer(input) {
  const normalized = String(input).replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);
  return Buffer.from(padded, 'base64');
}

function signPayload(payloadString, secret) {
  return crypto
    .createHmac('sha256', secret)
    .update(payloadString)
    .digest('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

function sha256(text) {
  return crypto.createHash('sha256').update(text).digest('hex');
}

function getConfiguredPasswordHash() {
  if (process.env.ADMIN_PASSWORD_HASH) {
    return String(process.env.ADMIN_PASSWORD_HASH).trim().toLowerCase();
  }
  if (process.env.ADMIN_PASSWORD) {
    return sha256(String(process.env.ADMIN_PASSWORD));
  }
  return DEFAULT_ADMIN_PASSWORD_HASH;
}

function getSessionSecret() {
  const configured = String(process.env.ADMIN_SESSION_SECRET || '').trim();
  if (configured.length >= 24) return configured;

  const seed = [
    process.env.SITE_ID || '',
    process.env.URL || '',
    process.env.ADMIN_USER || DEFAULT_ADMIN_USER,
    getConfiguredPasswordHash(),
    FALLBACK_SECRET_SEED
  ].join('|');

  return sha256(seed);
}

function parseCookies(event) {
  const raw = event.headers?.cookie || event.headers?.Cookie || '';
  if (!raw) return {};
  return raw.split(';').reduce((acc, pair) => {
    const idx = pair.indexOf('=');
    if (idx <= 0) return acc;
    const key = pair.slice(0, idx).trim();
    const value = pair.slice(idx + 1).trim();
    acc[key] = value;
    return acc;
  }, {});
}

function verifySessionToken(token, secret) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encodedPayload, signature] = parts;
  if (!encodedPayload || !signature) return null;

  let payloadString;
  try {
    payloadString = base64UrlDecode(encodedPayload);
  } catch {
    return null;
  }

  const expected = signPayload(payloadString, secret);
  const sigBuf = base64UrlToBuffer(signature);
  const expBuf = base64UrlToBuffer(expected);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }

  try {
    const payload = JSON.parse(payloadString);
    const now = Math.floor(Date.now() / 1000);
    if (!payload.exp || payload.exp < now) return null;
    if (!payload.sub || typeof payload.sub !== 'string') return null;
    return payload;
  } catch {
    return null;
  }
}

function isAllowedOrigin(origin) {
  if (!origin) return true;
  try {
    const parsed = new URL(origin);
    const { hostname, protocol } = parsed;
    if (!/^https?:$/.test(protocol)) return false;
    if (hostname === 'localhost' || hostname === '127.0.0.1') return true;
    if (origin === 'https://wahat-sudr.netlify.app') return true;
    if (/^[a-z0-9-]+--wahat-sudr\.netlify\.app$/i.test(hostname)) return true;

    const known = [process.env.URL, process.env.DEPLOY_PRIME_URL]
      .filter(Boolean)
      .map((u) => {
        try {
          return new URL(u).hostname;
        } catch {
          return null;
        }
      })
      .filter(Boolean);

    return known.includes(hostname);
  } catch {
    return false;
  }
}

function buildHeaders(origin) {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    Vary: 'Origin'
  };

  if (origin && isAllowedOrigin(origin)) {
    headers['Access-Control-Allow-Origin'] = origin;
    headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS';
    headers['Access-Control-Allow-Headers'] = 'Content-Type';
    headers['Access-Control-Allow-Credentials'] = 'true';
  }

  return headers;
}

function sanitizeAnnouncementLink(link) {
  const raw = String(link || '').trim();
  if (!raw) return '#contact';
  if (raw.startsWith('#')) {
    return /^#[a-zA-Z0-9_-]+$/.test(raw) ? raw : '#contact';
  }
  try {
    const parsed = new URL(raw);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') return parsed.toString();
  } catch {
    return '#contact';
  }
  return '#contact';
}

function sanitizeAnnouncement(input) {
  const data = input && typeof input === 'object' ? input : {};
  const safe = {
    icon: String(data.icon || '🎉').slice(0, 4),
    text: String(data.text || '').slice(0, 240).trim(),
    btnText: String(data.btnText || '').slice(0, 40).trim(),
    btnLink: sanitizeAnnouncementLink(String(data.btnLink || '#contact').slice(0, 400)),
    active: Boolean(data.active)
  };

  if (!safe.text) safe.active = false;
  return safe;
}

function unauthorized(headers) {
  return {
    statusCode: 401,
    headers,
    body: JSON.stringify({ error: 'Unauthorized' })
  };
}

function createStore(event) {
  // Required when running Netlify Functions in Lambda compatibility mode.
  connectLambda(event);
  return getStore(STORE_NAME);
}

exports.handler = async (event) => {
  const origin = event.headers?.origin || event.headers?.Origin || '';
  const headers = buildHeaders(origin);

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  if (origin && !isAllowedOrigin(origin)) {
    return { statusCode: 403, headers, body: JSON.stringify({ error: 'Origin not allowed' }) };
  }

  let store;
  try {
    store = createStore(event);
  } catch (err) {
    console.error('[announcement:store]', err?.message || 'Store init failed');
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Server storage is not configured' })
    };
  }

  if (event.httpMethod === 'GET') {
    try {
      const announcement = await store.get(STORE_KEY, { type: 'json' });
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ announcement: announcement || null })
      };
    } catch (err) {
      console.error('[announcement:get]', err?.message || 'Unknown error');
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Failed to load announcement' })
      };
    }
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  const sessionSecret = getSessionSecret();

  const cookies = parseCookies(event);
  const session = verifySessionToken(cookies[SESSION_COOKIE], sessionSecret);
  if (!session) {
    return unauthorized(headers);
  }

  let body;
  try {
    body = event.body ? JSON.parse(event.body) : {};
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const payload = sanitizeAnnouncement(body?.announcement || body);

  try {
    await store.setJSON(STORE_KEY, {
      ...payload,
      updatedAt: new Date().toISOString(),
      updatedBy: session.sub
    });
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ ok: true, announcement: payload })
    };
  } catch (err) {
    console.error('[announcement:set]', err?.message || 'Unknown error');
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Failed to save announcement' })
    };
  }
};
