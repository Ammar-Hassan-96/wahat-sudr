const MAX_BODY_CHARS = 30_000;
const MAX_MESSAGES = 10;
const MAX_MESSAGE_CHARS = 4_000;
const MAX_SYSTEM_CHARS = 3_000;
const DEFAULT_MAX_TOKENS = 400;
const MAX_MAX_TOKENS = 700;
const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_MAX_REQUESTS = 20;

const ipBuckets = new Map();

const ALLOWED_MODELS = new Set(
  (
    process.env.AI_ALLOWED_MODELS ||
    'claude-haiku-4-5-20251001,claude-sonnet-4-20250514'
  )
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
);

function isAllowedOrigin(origin) {
  if (!origin) return true;
  try {
    const parsed = new URL(origin);
    const { hostname, protocol } = parsed;
    if (!/^https?:$/.test(protocol)) return false;
    if (hostname === 'localhost' || hostname === '127.0.0.1') return true;
    if (origin === 'https://wahat-sudr.netlify.app') return true;
    if (/^[a-z0-9-]+--wahat-sudr\.netlify\.app$/i.test(hostname)) return true;
    const netlifyKnownUrls = [process.env.URL, process.env.DEPLOY_PRIME_URL]
      .filter(Boolean)
      .map((u) => {
        try {
          return new URL(u).hostname;
        } catch {
          return null;
        }
      })
      .filter(Boolean);
    if (netlifyKnownUrls.includes(parsed.hostname)) return true;
    return false;
  } catch {
    return false;
  }
}

function buildHeaders(origin) {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    Vary: 'Origin'
  };
  if (origin && isAllowedOrigin(origin)) {
    headers['Access-Control-Allow-Origin'] = origin;
    headers['Access-Control-Allow-Methods'] = 'POST, OPTIONS';
    headers['Access-Control-Allow-Headers'] = 'Content-Type';
  }
  return headers;
}

function badRequest(headers, error) {
  return { statusCode: 400, headers, body: JSON.stringify({ error }) };
}

function getClientIp(event) {
  const forwarded = event.headers?.['x-forwarded-for'] || event.headers?.['X-Forwarded-For'];
  if (forwarded) {
    return String(forwarded).split(',')[0].trim();
  }
  return event.headers?.['client-ip'] || event.headers?.['Client-Ip'] || 'unknown';
}

function isRateLimited(ip) {
  const now = Date.now();
  const list = ipBuckets.get(ip) || [];
  const fresh = list.filter((ts) => now - ts < RATE_LIMIT_WINDOW_MS);
  fresh.push(now);
  ipBuckets.set(ip, fresh);
  return fresh.length > RATE_LIMIT_MAX_REQUESTS;
}

function buildFallbackReply(question) {
  const text = String(question || '').trim();
  if (!text) {
    return 'ممكن توضيح سؤالك عن رأس سدر؟ الحجز متاح على واتساب +201144897131.';
  }
  if (/(حجز|booking|book)/i.test(text)) {
    return 'للحجز السريع في رأس سدر، يمكن التواصل على واتساب +201144897131 أو استخدام نموذج الحجز بالموقع.';
  }
  if (/(طقس|جو|weather)/i.test(text)) {
    return 'أفضل وقت لزيارة رأس سدر غالبًا من أكتوبر إلى أبريل. لو تحب، أرسل تاريخ رحلتك لاقتراح أنسب برنامج.';
  }
  if (/(كايت|kite|kitesurf)/i.test(text)) {
    return 'رأس سدر من أفضل أماكن الكايت سيرف في مصر بسبب الرياح المنتظمة. ينصح بالحجز المبكر خاصة في الموسم.';
  }
  return 'تم استلام سؤالك. للحصول على إجابة أدق وسريعة، تواصل مع فريق واحة سدر على واتساب +201144897131.';
}

function buildFallbackResponse(question) {
  return {
    id: `fallback_${Date.now()}`,
    type: 'message',
    role: 'assistant',
    model: 'local-fallback',
    content: [{ type: 'text', text: buildFallbackReply(question) }]
  };
}

exports.handler = async (event) => {
  const origin = event.headers?.origin || event.headers?.Origin || '';
  const headers = buildHeaders(origin);
  const ip = getClientIp(event);

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  if (origin && !isAllowedOrigin(origin)) {
    return { statusCode: 403, headers, body: JSON.stringify({ error: 'Origin not allowed' }) };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  if (isRateLimited(ip)) {
    return {
      statusCode: 429,
      headers: {
        ...headers,
        'Retry-After': '60'
      },
      body: JSON.stringify({ error: 'Too many requests, please retry in one minute' })
    };
  }

  const contentType = event.headers?.['content-type'] || event.headers?.['Content-Type'] || '';
  if (!String(contentType).toLowerCase().includes('application/json')) {
    return badRequest(headers, 'Content-Type must be application/json');
  }

  if (!event.body || event.body.length > MAX_BODY_CHARS) {
    return badRequest(headers, 'Request body is too large or empty');
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return badRequest(headers, 'Invalid JSON body');
  }

  if (typeof body.model !== 'string' || !ALLOWED_MODELS.has(body.model)) {
    return badRequest(headers, 'Invalid model');
  }

  if (!Array.isArray(body.messages) || body.messages.length === 0) {
    return badRequest(headers, 'messages must be a non-empty array');
  }

  body.messages = body.messages
    .slice(-MAX_MESSAGES)
    .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .map((m) => ({ role: m.role, content: m.content.slice(0, MAX_MESSAGE_CHARS) }));

  if (body.messages.length === 0) {
    return badRequest(headers, 'No valid messages after validation');
  }
  const lastUserMessage = [...body.messages].reverse().find((m) => m.role === 'user')?.content || '';

  body.max_tokens = Number.isFinite(body.max_tokens)
    ? Math.max(1, Math.min(Number(body.max_tokens), MAX_MAX_TOKENS))
    : DEFAULT_MAX_TOKENS;

  if (typeof body.system === 'string') {
    body.system = body.system.slice(0, MAX_SYSTEM_CHARS);
  } else {
    delete body.system;
  }

  const anthropicApiKey = String(process.env.ANTHROPIC_API_KEY || '').trim();

  if (!anthropicApiKey) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(buildFallbackResponse(lastUserMessage))
    };
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15_000);

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': anthropicApiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(body),
      signal: controller.signal
    });

    clearTimeout(timeout);
    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      data = { error: 'Unexpected upstream response' };
    }

    if (response.status === 401 || response.status === 403) {
      console.error('[AI Function Error] Upstream rejected API key');
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(buildFallbackResponse(lastUserMessage))
      };
    }

    return {
      statusCode: response.status,
      headers,
      body: JSON.stringify(data)
    };
  } catch (err) {
    clearTimeout(timeout);
    const isTimeout = err?.name === 'AbortError';
    console.error('[AI Function Error]', isTimeout ? 'Upstream timeout' : err?.message || 'Unknown error');
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(buildFallbackResponse(lastUserMessage))
    };
  }
};
